jQuery(document).ready(function () {
//    jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 21px;margin-bottom: 16px; margin-left: 87px;"href="' + ink_advert.url + '" class="button" target="_blank">' + ink_advert.pro + '</a><a class="button-primary" style="margin-top: 5px;margin-bottom: 20px; margin-left: 87px;"href="' + ink_advert.support_url + '" class="button" target="_blank">' + ink_advert.support_text + '</a>');
    jQuery('.wp-full-overlay-sidebar-content').prepend('<a class="button-primary" style=";margin: 20px 0; margin-left: 55px;"href="' + ink_advert.support_url + '" class="button" target="_blank">' + ink_advert.support_text + '</a>');
});
