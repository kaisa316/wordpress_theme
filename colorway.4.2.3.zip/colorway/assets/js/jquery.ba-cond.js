/*
 * cond - v0.1 - 6/10/2009
 * http://benalman.com/projects/jquery-cond-plugin/
 * 
 * Copyright (c) 2009 "Cowboy" Ben Alman
 * Licensed under the MIT license
 * http://benalman.com/about/license/
 * 
 * Based on suggestions and sample code by Stephen Band and DBJDBJ in the
 * jquery-dev Google group: http://bit.ly/jqba1
 */
(function ($) {
    $.fn.cond = function () {
        var e, a = arguments, b = 0, f, d, c;
        while (!f && b < a.length) {
            f = a[b++];
            d = a[b++];
            f = $.isFunction(f) ? f.call(this) : f;
            c = !d ? f : f ? d.call(this, f) : e
        }
        return c !== e ? c : this
    }
})(jQuery);